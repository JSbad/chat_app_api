const WebSocketServer = require('ws');


const wss = new WebSocketServer.Server({port: 8081});
  
wss.on("connection", ws =>{
  console.log("connected");

  ws.on("message", data => {
    console.log(`${data}`);
    
  });

  ws.on("close", data => {
    console.log("disconnected");
  });

});
console.log("server running on port 8081");